(function() {  //加载
    var obj =  {};
    obj.loadScript = function(url,callback){
      var doc = document;
      var script = doc.createElement("script");
      script.type = "text/javascript";
      if(script.readyState){  //IE
        script.onreadystatechange = function(){
          if(script.readyState=="load"||script.readyState=="complete"){
            script.onreadystatechange = null;
            callback();
          }
        };
      }else{
        script.onload = function(){
          callback();
        };
      }
      script.src = url;
      doc.getElementsByTagName("head")[0].appendChild(script);
    };
    var jsList = [
      "js/utils/hex.js",
      "js/utils/byteUtil.js",
      "js/crypto/sm4-1.0.js",
      "js/ext/jsbn.js",
      "js/ext/jsbn2.js",
      "js/ext/prng4.js",
      "js/ext/rng.js",
      "js/crypto/sm3-1.0.js",
      "js/ext/ec.js",
      "js/ext/ec-patch.js",
    ];
    function callback(){
        jsList.length?obj.loadScript(jsList.shift(),callback)
          :(function(){time = null})();
    }
    var time = setTimeout(function(){obj.loadScript(jsList.shift(),callback)},25);
  })();